import pygame
from pygame.locals import *
import random


class Ball():
    def __init__(self, window, windowWidth, windowHeight):

        self.wallcnt=0
        self.snd=pygame.mixer.Sound('sounds/wall.mp3')

        self.window = window
        self.windowWidth = windowWidth
        self.windowHeight = windowHeight

        self.image = pygame.image.load('images/ball.jpg')
        ballRect = self.image.get_rect()
        self.width = ballRect.width
        self.height = ballRect.height
        self.maxWidth = windowWidth - self.width
        self.maxHeight = windowHeight - self.height

        self.x = windowWidth/2-self.width/2
        #random.randrange(0, self.maxWidth)
        self.y =windowHeight/2-self.height/2
        #random.randrange(0, self.maxHeight)

        speedsList = [-4, -3, -2, -1, 1, 2, 3, 4]
        self.xSpeed = random.choice(speedsList)
        self.ySpeed = random.choice(speedsList)

    def reset(self):
        speedsList = [-4, -3, -2, -1, 1, 2, 3, 4]
        self.xSpeed = random.choice(speedsList)
        self.ySpeed = random.choice(speedsList)


        self.x = self.windowWidth/2-self.width/2
        #random.randrange(0, self.maxWidth)
        self.y =self.windowHeight/2-self.height/2
        self.wallcnt=0
    def update(self):
        if (self.x < 0) or (self.x >= self.maxWidth):
            self.xSpeed = -self.xSpeed
            self.snd.play()
            self.wallcnt+=1


        if (self.y < 0) or (self.y >= self.maxHeight):
            self.ySpeed = -self.ySpeed
            self.snd.play()
            self.wallcnt+=1


        self.x = self.x + self.xSpeed
        self.y = self.y + self.ySpeed

    def draw(self):
        self.window.blit(self.image, (self.x, self.y))
