import pygame
from pygame.locals import *
class MyButton():
    def __init__(self,win,loc,up,down):
        self.win=win
        self.loc=loc
        self.upimg=pygame.image.load(up)
        self.downimg=pygame.image.load(down)

        self.rect=self.upimg.get_rect()
        self.rect[0]=loc[0]
        self.rect[1]=loc[1]

        self.state='idle'
        
    def eventHand(self,obj):
        if obj.type not in (MOUSEMOTION,MOUSEBUTTONUP,MOUSEBUTTONDOWN):
            return False
        is_mouse=self.rect.collidepoint(obj.pos)
        if self.state=='idle':
            if (obj.type==MOUSEBUTTONDOWN) and is_mouse:
                self.state='armed'
                
        elif self.state=='armed':
            if (obj.type==MOUSEBUTTONUP) and is_mouse:
                self.state='idle'
                return True
            
            if (obj.type==MOUSEBUTTONDOWN) and (not is_mouse):
                self.state='disarmed'
                
        elif self.state=='disarmed':
            if is_mouse:
                self.state='armed'
            elif obj.type==MOUSEBUTTONUP:
                self.state='idle'
                
        return False
    
    def draw(self):
        if self.state=='armed':
            self.win.blit(self.downimg,self.loc)
        else:
            self.win.blit(self.upimg,self.loc)
