import pygame
from pygame.locals import *
class MyText():
    def __init__(s,win,loc,val,col):
        pygame.font.init()
        s.win=win
        s.loc=loc
        s.font=pygame.font.SysFont(None,30)
        s.txtcol=col
        s.txt=None
        s.setvalue(val)
    def setvalue(s,txt):
        if s.txt==txt:
            return
        s.txt=txt
        s.txtsurf=s.font.render(s.txt,True,s.txtcol)
    def draw(s):
        s.win.blit(s.txtsurf,s.loc)
