import sys
import pygame
from pygame.locals import *
from MyButton import *
from Ball import *
from MyText import *
pygame.init()
WIN_W,WIN_H=640,480
FPS=30

win=pygame.display.set_mode((WIN_W,WIN_H))
pygame.display.set_caption('Main Game')
clock=pygame.time.Clock()

startbtn=MyButton(win,(0,0),'images/startup.png','images/startdown.png')
stopbtn=MyButton(win,(0,50),'images/stopup.png','images/stopdown.png')
resetbtn=MyButton(win,(0,100),'images/resetup.png','images/resetdown.png')

pygame.mixer.music.load('sounds/bgm.mp3')
pygame.mixer.music.play()



label1=MyText(win,(200,0),'fuc',(255,0,0))
myball=Ball(win,WIN_W,WIN_H)

isstart=False
timecnt=0
while True:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
        if startbtn.eventHand(event):
            print('Start!!!')
            isstart=True
        if stopbtn.eventHand(event):
            print('Stop!!!')
            isstart=False
        if resetbtn.eventHand(event):
            print('Reset!!!')
            myball.reset()
            isstart=False
            timecnt=0
    win.fill((255,255,255))
    myball.draw()
    sec=timecnt//FPS
    minute=sec//60
    
    label1.setvalue(f'{myball.wallcnt} times , {minute}m {sec%60}s {timecnt%FPS}')
    label1.draw()
    if isstart:
        myball.update()
        timecnt+=1
        

    startbtn.draw()
    stopbtn.draw()
    resetbtn.draw()
    
    pygame.display.update()
    clock.tick(FPS)
