import sys
import pygame
from pygame.locals import *
from MyButton import *
from Ball import *
from MyText import *
pygame.init()
WIN_W,WIN_H=640,480
FPS=30

win=pygame.display.set_mode((WIN_W,WIN_H))
pygame.display.set_caption('Main Game 02')
clock=pygame.time.Clock()


pygame.mixer.music.load('sounds/bgm.mp3')
pygame.mixer.music.play()



label1=MyText(win,(200,0),'fuc',(255,0,0))
myball=Ball(win,WIN_W,WIN_H)

ballL=Ball(win,WIN_W,WIN_H)
ballR=Ball(win,WIN_W,WIN_H)
ballL.x=0
ballL.y=0
ballR.x=ballL.maxWidth
ballR.y=0
isstart=False
timecnt=0
isR=False
isL=False
isCru=False
while True:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type==pygame.MOUSEBUTTONDOWN:
            print('Click!!!')
            isstart=True
        elif event.type==pygame.KEYDOWN:
            if event.key==pygame.K_a:
                isCru=True
            elif event.key==pygame.K_s:
                isCru=False
            elif event.key==pygame.K_d:
                isL=True
            elif event.key==pygame.K_f:
                isR=True
    win.fill((255,255,255))
    myball.draw()
    if isCru:
        pygame.draw.rect(win,(0,0,0),(150,150,35,35*3),0)
        pygame.draw.rect(win,(0,0,0),(150-35,150+35,35*3,35),0)
    if isL:ballL.draw()
    if isR:ballR.draw()
    if isstart:
        myball.update()
        timecnt+=1
        

    
    pygame.display.update()
    clock.tick(FPS)
