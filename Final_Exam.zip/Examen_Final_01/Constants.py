# Constants

WHITE = (255, 255, 255)
HIGHER = 'higher'
LOWER = 'lower'