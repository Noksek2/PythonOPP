#  Game class

import pygame
import pygwidgets
from Constants import *
from Deck import *
from Card import *

class Game():
    CARD_OFFSET = 110
    CARDS_TOP = 300
    CARDS_LEFT = 75
    NCARDS = 8
    POINTS_CORRECT = 15
    POINTS_INCORRECT = 10

    def __init__(self, window):
        self.rexdraw=False
        self.dinodraw=False 
        self.TRexList = [('images/TRex/f1.gif', .1),
                      ('images/TRex/f2.gif', .1),
                      ('images/TRex/f3.gif', .1),
                      ('images/TRex/f4.gif', .1),
                      ('images/TRex/f5.gif', .1),
                      ('images/TRex/f6.gif', .1),
                      ('images/TRex/f7.gif', .1),
                      ('images/TRex/f8.gif', .1),
                      ('images/TRex/f9.gif', .1),
                      ('images/TRex/f10.gif', .1)]
        self.TRexani = pygwidgets.Animation(window, (180, 140), self.TRexList, \
            autoStart=True, loop=True, nIterations=3, callBack=None)
            
        dinoList = [('images/Dinowalk/f1.png', .1),
                      ('images/Dinowalk/f2.png', .1),
                      ('images/Dinowalk/f3.png', .1),
                      ('images/Dinowalk/f4.png', .1),
                      ('images/Dinowalk/f5.png', .1),
                      ('images/Dinowalk/f6.png', .1),
                      ('images/Dinowalk/f7.png', .1),
                      ('images/Dinowalk/f8.png', .1),
                      ('images/Dinowalk/f9.png', .1),
                      ('images/Dinowalk/f10.png', .1),
                      ('images/Dinowalk/f11.png', .1),
                      ('images/Dinowalk/f12.png', .1),
                      ('images/Dinowalk/f13.png', .1),
                      ('images/Dinowalk/f14.png', .1),
                      ('images/Dinowalk/f15.png', .1),
                      ('images/Dinowalk/f16.png', .1),
                      ('images/Dinowalk/f17.png', .1)]
        self.dinoani = pygwidgets.Animation(window, (180, 140), dinoList, \
            autoStart=True, loop=True, nIterations=3, callBack=None)

        self.window = window
        self.oDeck = Deck(self.window)
        self.score = 100
        self.scoreText = pygwidgets.DisplayText(window, (300, 164),
                                   'Score: ' + str(self.score),
                                    fontSize=36, textColor=WHITE,
                                    justified='right')

        self.messageText = pygwidgets.DisplayText(window, (50, 460),
                                    '', width=900, justified='center',
                                    fontSize=36, textColor=WHITE)
        pygame.mixer.init()
        self.loserSound = pygame.mixer.Sound("sounds/loser.wav")
        self.winnerSound = pygame.mixer.Sound("sounds/ding.wav")
        self.cardShuffleSound = pygame.mixer.Sound("sounds/cardShuffle.wav")

        self.cardXPositionsList = []
        thisLeft = Game.CARDS_LEFT
        # Calculate the x positions of all cards, once
        for cardNum in range(Game.NCARDS):
            self.cardXPositionsList.append(thisLeft)
            thisLeft = thisLeft + Game.CARD_OFFSET

        self.reset()  # start a round of the game

    def reset(self):  # this method is called when a new round starts
        self.cardShuffleSound.play()
        self.cardList = []
        self.oDeck.shuffle()
        for cardIndex in range(0, Game.NCARDS):  # deal out cards
            oCard = self.oDeck.getCard()
            self.cardList.append(oCard)
            thisXPosition = self.cardXPositionsList[cardIndex]
            oCard.setLoc((thisXPosition, Game.CARDS_TOP))

        self.showCard(0)
        self.cardNumber = 0
        self.currentCardName, self.currentCardValue = \
                                         self.getCardNameAndValue(self.cardNumber)

        self.messageText.setValue('Starting card is ' + self.currentCardName +
                                                '. Will the next card be higher or lower?')
        self.rexdraw=False
        self.dinodraw=False
    def getCardNameAndValue(self, index):
        oCard = self.cardList[index]
        theName = oCard.getName()
        theValue = oCard.getValue()
        return theName, theValue

    def showCard(self, index):
        oCard = self.cardList[index]
        oCard.reveal()

    def hitHigherOrLower(self, higherOrLower):
        self.cardNumber = self.cardNumber + 1
        self.showCard(self.cardNumber)
        nextCardName, nextCardValue = self.getCardNameAndValue(self.cardNumber)

        if higherOrLower == HIGHER:
            if nextCardValue > self.currentCardValue:
                self.score = self.score + Game.POINTS_CORRECT
                self.messageText.setValue('Yes, the ' + nextCardName + ' was higher')
                self.winnerSound.play()
                self.rexdraw=False
                self.dinodraw=True
            else:
                self.score = self.score - Game.POINTS_INCORRECT
                self.messageText.setValue('No, the ' + nextCardName + ' was not higher')
                self.loserSound.play()
                self.rexdraw=True
                self.dinodraw=False

        else:  # user hit the Lower button
            if nextCardValue < self.currentCardValue:
                self.score = self.score + Game.POINTS_CORRECT
                self.messageText.setValue('Yes, the ' + nextCardName + ' was lower')
                self.winnerSound.play()
                self.rexdraw=False
                self.dinodraw=True
            else:
                self.score = self.score - Game.POINTS_INCORRECT
                self.messageText.setValue('No, the ' + nextCardName + ' was not lower')
                self.loserSound.play()
                self.rexdraw=True
                self.dinodraw=False

        self.scoreText.setValue('Score: ' + str(self.score))

        self.currentCardValue = nextCardValue  # set up for the next card 

        done = (self.cardNumber == (Game.NCARDS - 1))  # did we reach the last card?
        return done
    def handleREX(self,event):
        if self.TRexani.handleEvent(event):
            self.TRexani.start()
        if self.dinoani.handleEvent(event):
            self.dinoani.start()
       
    def draw(self):
        # Tell each card to draw itself
        for oCard in self.cardList:
            oCard.draw()

        self.scoreText.draw()
        self.messageText.draw()
        self.TRexani.update()
        self.dinoani.update()
        if self.rexdraw:self.TRexani.draw()
        if self.dinodraw:self.dinoani.draw()
    def enddraw(s):
        pass
