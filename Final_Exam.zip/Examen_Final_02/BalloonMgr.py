#  Balloon manager

import pygame
import random
from pygame.locals import *
import pygwidgets
from BalloonConstants import *
from Balloon import *

#  BalloonMgr manages a list of Balloon objects
class BalloonMgr():
    def __init__(self, window, maxWidth, maxHeight):
        self.isdino=False
        self.window = window
        self.maxWidth = maxWidth
        self.maxHeight = maxHeight
        
        dinoList = [('images/Dinowalk/f1.png', .1),
                      ('images/Dinowalk/f2.png', .1),
                      ('images/Dinowalk/f3.png', .1),
                      ('images/Dinowalk/f4.png', .1),
                      ('images/Dinowalk/f5.png', .1),
                      ('images/Dinowalk/f6.png', .1),
                      ('images/Dinowalk/f7.png', .1),
                      ('images/Dinowalk/f8.png', .1),
                      ('images/Dinowalk/f9.png', .1),
                      ('images/Dinowalk/f10.png', .1),
                      ('images/Dinowalk/f11.png', .1),
                      ('images/Dinowalk/f12.png', .1),
                      ('images/Dinowalk/f13.png', .1),
                      ('images/Dinowalk/f14.png', .1),
                      ('images/Dinowalk/f15.png', .1),
                      ('images/Dinowalk/f16.png', .1),
                      ('images/Dinowalk/f17.png', .1)]
        self.dinoani = pygwidgets.Animation(window, (550, 50), dinoList, \
            autoStart=True, loop=True, nIterations=3, callBack=None)
        self.text =pygwidgets.DisplayText(window, (550, 100),
                                    'Clicked!', width=900, justified='center',
                                    fontSize=36, textColor=(255,100,100))
    def start(self):
        self.balloonList = []
        self.nPopped = 0
        self.nMissed = 0
        self.score = 0
        self.isdino=False

        for balloonNum in range(0, N_BALLOONS):
            randomBalloonClass = random.choice((BalloonSmall,
                                                                    BalloonMedium,
                                                                    BalloonLarge))
            oBalloon = randomBalloonClass(self.window, self.maxWidth,
                                                        self.maxHeight, balloonNum)
            self.balloonList.append(oBalloon)


    def handleEvent(self, event):
        if event.type == MOUSEBUTTONDOWN:
            # Go 'reversed' so top-most balloon gets popped
            for oBalloon in reversed(self.balloonList):
                wasHit, nPoints = oBalloon.clickedInside(event.pos)
                if wasHit:
                    if nPoints > 0: # remove this balloon
                        self.balloonList.remove(oBalloon)  
                        self.nPopped = self.nPopped + 1
                        self.score = self.score + nPoints
                        self.isdino=True
                    return  # no need to check others
                else:self.isdino=False
        if self.dinoani.handleEvent(event):
            self.dinoani.start()
        

    def update(self):
        for oBalloon in self.balloonList:
            status = oBalloon.update()
            if status == BALLOON_MISSED:
                # Balloon went off the top, remove it
                self.balloonList.remove(oBalloon)
                self.nMissed = self.nMissed + 1
                self.isdino=False

    def getScore(self):
        return self.score

    def getCountPopped(self):
        return self.nPopped

    def getCountMissed(self):
        return self.nMissed

    def draw(self):
        for oBalloon in self.balloonList:
            oBalloon.draw()
        self.dinoani.update()
        if self.isdino:
            self.dinoani.draw()
            self.text.draw()
